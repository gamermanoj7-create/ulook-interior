ULOOK INTERIOR — PREMIUM MOBILE + 3D VIDEO FIX (V4)

What changed in this build
- Restored and improved the mobile layout so sections do not stay blank while reveal effects initialize.
- Rebalanced the homepage hero and made the hero residence image larger.
- Improved the premium gold/charcoal styling, spacing, gallery cards and 3D video frames.
- Externalised the large inline photos into optimized local WebP assets.
- Uses the sharper 1080p MP4 source on high-DPI phones; lower-resolution mobile MP4 is used on low-DPI devices.
- Adjusted the first useful frame for the bookcase and house build sequences.
- Keeps the scroll-linked 3D videos working with HTTP byte-range requests.
- Local server sends no-store headers to prevent an older cached page/assets from appearing.

TERMUX SETUP
1) Stop the old server with CTRL+C.
2) In Termux, enable storage access once if needed:
   termux-setup-storage
3) Extract this ZIP into a NEW folder (do not overwrite the old folder):
   cd ~/storage/downloads
   unzip -o ulook-interior-premium-v4.zip -d ulook-v4
4) Enter the new website folder:
   cd ~/storage/downloads/ulook-v4
5) Start the included byte-range server (do not use python -m http.server):
   python server.py
6) Open this address in Chrome or Brave:
   http://127.0.0.1:8080/

HOW TO TEST THE 3D BUILD VIDEOS
- Scroll to “Built piece by piece” and scroll slowly through the entire section.
  The bookcase builds from its frame to shelves, panels and finishing.
- Continue to “From first slab to finished home” and scroll slowly through that section.
  The house progresses from structure to walls, roof and finished exterior.
- The animations are tied to page scroll; they do not play as ordinary autoplay videos.

IMPORTANT
- Keep Termux running while viewing the local website.
- Use a fresh browser tab after switching to this V4 folder. The server disables caching for the local preview.
- If port 8080 is busy, stop the old server first. Alternative: PORT=8081 python server.py, then open http://127.0.0.1:8081/
- This ZIP is a local preview build; it does not deploy or publish the site.
